import dtit.microFeaturesGenerator as vf

print(vf.pyInitializeMicroFeatures())
