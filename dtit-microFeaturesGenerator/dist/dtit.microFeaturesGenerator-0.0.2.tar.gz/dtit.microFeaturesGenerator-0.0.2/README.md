# CRC Library

## Introduction
STM32 compatible MFCC & SFFT using LiteMath

### Install
pip install dtit.microFeaturesGenerator

### Check
Execute
   
      * python dtit\microFeaturesGenerator\tests\hello.py *

should echo with "dtit.microFeaturesGenerator"

### Usage
Please refer to examples in tests directory.

### Error Report
Please email to dev@datatellit.com
