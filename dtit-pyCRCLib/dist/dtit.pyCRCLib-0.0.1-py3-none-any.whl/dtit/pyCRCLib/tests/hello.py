import dtit.pyCRCLib as crc

print(crc.name)
