# CRC Library

## Introduction
This is DTIT CRC library, supporting ModBus and NB-IoT CRC16 for now.

### Install
pip install dtit.pyCRCLib

### Check
Execute
   
   python dtit\pyCRCLib\tests\hello.py

should echo with "dtit.pyCRCLib"

### Usage
Please refer to examples in tests directory.

### Error Report
Please email to dev@datatellit.com
