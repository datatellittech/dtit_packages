import dtit.pyLiteMath as lmath

print(lmath.name)
