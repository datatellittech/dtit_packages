# LiteMath Library

## Introduction
This is DTIT integer math library. It is very lite without any float type or standard C math lib.

### Install
pip install dtit.pyLiteMath

### Check
Execute
   
          * python dtit\pyLiteMath\tests\hello.py *

should echo with "dtit.pyLiteMath"

### Usage
Please refer to examples in tests directory.

### Error Report
Please email to dev@datatellit.com
